# Ukázkový projekt: Osobní databáze
## KivyMD a SQLAlchemy
 